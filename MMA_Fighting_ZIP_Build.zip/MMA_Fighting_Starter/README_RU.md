# MMA Fighting Prototype — стартовый Unity-проект

Это **первый технический прототип**, а не готовая игра уровня UFC 3–5. Сцена создаётся автоматически при Android-сборке: октагон, два простых персонажа-заглушки, камера, виртуальный джойстик и четыре сенсорные кнопки атак. Детализированные модели, риг, спортивные анимации, звук, меню и полноценная система боя добавляются следующими этапами.

## Версия Unity

Проект зафиксирован на Unity `6000.0.23f1` (ветка Unity 6). Через Unity Hub установи Android Build Support, Android SDK & NDK Tools и OpenJDK.

## Подпись APK и обновления

APK подписывается постоянным release-keystore через GitHub Actions. **Не теряй keystore и пароли.** Если потерять ключ или заменить его, Android не позволит установить обновление поверх старой установки. Не загружай keystore в публичный репозиторий и не отправляй его в чат.

### 1. Используй подготовленный keystore

Для этого проекта уже создан постоянный файл `mma-release.keystore` и alias `mma-release`. Скачай его отдельным файлом из комплекта проекта и храни резервную копию отдельно от GitHub. Пароль находится в отдельном файле `MMA_SIGNING_CREDENTIALS.txt` — не коммить ни его, ни keystore в репозиторий.

### 2. Добавь GitHub Repository Secrets

В репозитории открой **Settings → Secrets and variables → Actions → New repository secret** и добавь:

- `ANDROID_KEYSTORE_BASE64` — Base64-содержимое файла keystore. Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes('.\mma-release.keystore'))`. Linux: `base64 -w 0 mma-release.keystore`.
- `ANDROID_KEYSTORE_PASS` — пароль из `MMA_SIGNING_CREDENTIALS.txt`.
- `ANDROID_KEYALIAS_NAME` — `mma-release`.
- `ANDROID_KEYALIAS_PASS` — тот же пароль.
- `UNITY_LICENSE` — содержимое файла лицензии Unity, необходимое GameCI.

Не вставляй значения секретов в исходники, коммиты или публичные сообщения.

### 3. Загрузка ZIP и первый запуск GitHub Actions

Можно хранить Unity-проект в репозитории одним ZIP-файлом. Положи ровно один ZIP с проектом в корень репозитория (например, `MMA_Fighting_Starter.zip`). Workflow распакует архив и найдёт папку с `ProjectSettings/ProjectVersion.txt` автоматически.

**Важный нюанс:** GitHub не запускает workflow, который лежит внутри ZIP. Поэтому один раз отдельно создай в самом репозитории файл `.github/workflows/android.yml` и вставь в него содержимое одноимённого файла из папки проекта. После этого загрузи ZIP в корень репозитория. Открой **Actions → Build signed Android APK from ZIP → Run workflow**. После успешной сборки скачай `MMA-Fighting-APK` из Artifacts.

В корне репозитория должен лежать только один ZIP с Unity-проектом. Не загружай туда keystore, файл с паролями или Base64-файл.

### Обновления

Во всех версиях остаются одинаковыми Application ID (`com.indie.mmafighting.prototype`) и ключ подписи. `versionCode` увеличивается по номеру запуска GitHub Actions. Поэтому новые APK можно устанавливать поверх предыдущих, пока не меняются Application ID и keystore.

## Что уже заложено

- Горизонтальная ориентация экрана.
- Android ARM64 и IL2CPP.
- Простая арена и две геометрические модели-заглушки.
- Камера следит за обоими бойцами.
- Сенсорный джойстик и четыре кнопки-заглушки атак.

## Ограничения

В этом ZIP нет готового APK: его создаст GitHub Actions после настройки Unity License и секретов подписи. Keystore подготовлен отдельно от ZIP и должен храниться у тебя в резервной копии; не загружай его в публичный репозиторий. Это стартовый прототип, а не законченная игра.
