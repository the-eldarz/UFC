using UnityEngine;

namespace MMA
{
    [RequireComponent(typeof(CharacterController))]
    public class FighterController : MonoBehaviour
    {
        public float moveSpeed = 3.2f;
        public float rotationSpeed = 12f;
        public Transform opponent;
        public Animator animator;
        private CharacterController controller;
        private Vector2 moveInput;
        private float attackTimer;

        public bool IsAttacking => attackTimer > 0f;

        void Awake() => controller = GetComponent<CharacterController>();

        public void SetMoveInput(Vector2 input) => moveInput = Vector2.ClampMagnitude(input, 1f);

        void Update()
        {
            Vector3 forward = Vector3.forward;
            if (opponent != null)
            {
                Vector3 toOpponent = opponent.position - transform.position;
                toOpponent.y = 0;
                if (toOpponent.sqrMagnitude > 0.01f)
                    transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(toOpponent), rotationSpeed * Time.deltaTime);
                forward = transform.forward;
            }

            Vector3 right = Vector3.Cross(Vector3.up, forward).normalized;
            Vector3 motion = (forward * moveInput.y + right * moveInput.x) * moveSpeed;
            controller.SimpleMove(motion);
            attackTimer = Mathf.Max(0f, attackTimer - Time.deltaTime);
            if (animator != null)
            {
                animator.SetFloat("Move", moveInput.magnitude);
                animator.SetBool("Attacking", IsAttacking);
            }
        }

        public void Attack(int kind)
        {
            if (attackTimer > 0f) return;
            attackTimer = 0.38f;
            if (animator != null) animator.SetTrigger("Attack" + Mathf.Clamp(kind, 1, 4));
        }
    }
}
