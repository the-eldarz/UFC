using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace MMA
{
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform background;
        public RectTransform handle;
        public FighterController target;
        public float radius = 70f;

        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);
        public void OnDrag(PointerEventData eventData)
        {
            if (background == null || handle == null) return;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(background, eventData.position, eventData.pressEventCamera, out Vector2 local);
            Vector2 value = Vector2.ClampMagnitude(local / radius, 1f);
            handle.anchoredPosition = value * radius;
            if (target != null) target.SetMoveInput(value);
        }
        public void OnPointerUp(PointerEventData eventData)
        {
            if (handle != null) handle.anchoredPosition = Vector2.zero;
            if (target != null) target.SetMoveInput(Vector2.zero);
        }
    }
}
