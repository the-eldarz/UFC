using UnityEngine;

namespace MMA
{
    public class SimpleFightCamera : MonoBehaviour
    {
        public Transform targetA;
        public Transform targetB;
        public float height = 3.4f;
        public float distance = 6.8f;
        public float smooth = 4f;
        void LateUpdate()
        {
            if (targetA == null || targetB == null) return;
            Vector3 midpoint = (targetA.position + targetB.position) * 0.5f;
            Vector3 direction = (targetB.position - targetA.position).normalized;
            Vector3 desired = midpoint - direction * distance + Vector3.up * height;
            transform.position = Vector3.Lerp(transform.position, desired, Time.deltaTime * smooth);
            Vector3 look = midpoint + Vector3.up * 1.0f;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(look - transform.position), Time.deltaTime * smooth);
            float spacing = Vector3.Distance(targetA.position, targetB.position);
            GetComponent<Camera>().fieldOfView = Mathf.Lerp(48f, 60f, Mathf.InverseLerp(2f, 6f, spacing));
        }
    }
}
