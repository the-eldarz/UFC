using UnityEngine;
using UnityEngine.EventSystems;

namespace MMA
{
    public class AttackButton : MonoBehaviour, IPointerDownHandler
    {
        [Range(1, 4)] public int attackKind = 1;
        public FighterController target;
        public void OnPointerDown(PointerEventData eventData)
        {
            if (target != null) target.Attack(attackKind);
        }
    }
}
