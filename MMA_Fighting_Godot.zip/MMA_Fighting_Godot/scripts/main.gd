extends Node3D

const FighterScript = preload("res://scripts/fighter.gd")
const JoystickScript = preload("res://scripts/virtual_joystick.gd")

var player: DemoFighter
var rival: DemoFighter
var camera: Camera3D
var joystick_value := Vector2.ZERO
var block_held := false
var status_label: Label
var round_time := 180.0

func _ready() -> void:
	_setup_world()
	_setup_arena()
	_setup_fighters()
	_setup_camera()
	_setup_hud()

func _setup_world() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#111b2b")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#a9bfdc")
	env.ambient_light_energy = 0.55
	world.environment = env
	add_child(world)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-52, -28, 0)
	key.light_energy = 1.25
	key.shadow_enabled = true
	add_child(key)
	var fill := OmniLight3D.new()
	fill.position = Vector3(0, 4, 2)
	fill.light_color = Color("#8eb7ff")
	fill.light_energy = 0.65
	fill.omni_range = 12
	add_child(fill)

func _setup_arena() -> void:
	var floor := MeshInstance3D.new()
	var floor_mesh := CylinderMesh.new()
	floor_mesh.top_radius = 5.7
	floor_mesh.bottom_radius = 5.7
	floor_mesh.height = 0.25
	floor_mesh.radial_segments = 8
	floor.mesh = floor_mesh
	floor.position.y = -0.14
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("#202a37")
	mat.roughness = 0.88
	floor.material_override = mat
	add_child(floor)
	var mat_top := StandardMaterial3D.new()
	mat_top.albedo_color = Color("#d5dbe3")
	mat_top.roughness = 0.95
	var canvas := MeshInstance3D.new()
	var top := CylinderMesh.new()
	top.top_radius = 5.58
	top.bottom_radius = 5.58
	top.height = 0.015
	top.radial_segments = 8
	canvas.mesh = top
	canvas.position.y = 0.0
	canvas.material_override = mat_top
	add_child(canvas)
	# Low, stylized perimeter rails define the octagon without obstructing the camera.
	for i in range(8):
		var a1 := TAU * float(i) / 8.0 + PI / 8.0
		var a2 := TAU * float(i + 1) / 8.0 + PI / 8.0
		var p1 := Vector3(cos(a1) * 5.55, 0.78, sin(a1) * 5.55)
		var p2 := Vector3(cos(a2) * 5.55, 0.78, sin(a2) * 5.55)
		var post := MeshInstance3D.new()
		var post_mesh := CylinderMesh.new()
		post_mesh.top_radius = 0.10
		post_mesh.bottom_radius = 0.10
		post_mesh.height = 1.55
		post.mesh = post_mesh
		post.position = p1
		post.material_override = _material(Color("#313d4d"))
		add_child(post)
		var rail := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(p1.distance_to(p2), 0.07, 0.07)
		rail.mesh = box
		rail.position = (p1 + p2) * 0.5
		rail.position.y = 0.78
		rail.look_at(Vector3(p2.x, rail.position.y, p2.z), Vector3.UP)
		rail.material_override = _material(Color("#536276"))
		add_child(rail)

func _material(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.78
	return m

func _setup_fighters() -> void:
	player = FighterScript.new()
	player.name = "BlueCorner"
	player.body_color = Color("#236bb7")
	player.glove_color = Color("#e8edf4")
	player.is_player = true
	add_child(player)
	player.position = Vector3(-1.35, 0.12, 0.2)
	rival = FighterScript.new()
	rival.name = "RedCorner"
	rival.body_color = Color("#a9363e")
	rival.glove_color = Color("#f0d5d1")
	add_child(rival)
	rival.position = Vector3(1.35, 0.12, -0.2)

func _setup_camera() -> void:
	camera = Camera3D.new()
	camera.position = Vector3(0, 7.2, 10.5)
	camera.current = true
	camera.fov = 48
	add_child(camera)
	camera.look_at(Vector3(0, 1.0, 0), Vector3.UP)

func _setup_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var top_panel := PanelContainer.new()
	top_panel.anchor_left = 0.5
	top_panel.anchor_right = 0.5
	top_panel.offset_left = -210
	top_panel.offset_right = 210
	top_panel.offset_top = 16
	top_panel.offset_bottom = 86
	layer.add_child(top_panel)
	var top_row := HBoxContainer.new()
	top_row.alignment = BoxContainer.ALIGNMENT_CENTER
	top_panel.add_child(top_row)
	var blue := Label.new()
	blue.text = "  BLUE  "
	blue.add_theme_color_override("font_color", Color("#65b4ff"))
	top_row.add_child(blue)
	status_label = Label.new()
	status_label.text = "ROUND 1  •  3:00"
	status_label.add_theme_font_size_override("font_size", 22)
	top_row.add_child(status_label)
	var red := Label.new()
	red.text = "  RED  "
	red.add_theme_color_override("font_color", Color("#ff7777"))
	top_row.add_child(red)
	var hint := Label.new()
	hint.text = "DEMO ARENA  •  MOVE / ACTION / BLOCK"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.anchor_left = 0.5
	hint.anchor_right = 0.5
	hint.offset_left = -230
	hint.offset_right = 230
	hint.offset_top = 96
	hint.offset_bottom = 126
	hint.add_theme_color_override("font_color", Color(0.82, 0.88, 0.96, 0.82))
	hint.add_theme_font_size_override("font_size", 15)
	layer.add_child(hint)
	var joy := JoystickScript.new()
	joy.anchor_left = 0
	joy.anchor_top = 1
	joy.anchor_bottom = 1
	joy.offset_left = 28
	joy.offset_top = -198
	joy.offset_right = 198
	joy.offset_bottom = -28
	joy.vector_changed.connect(func(v: Vector2): joystick_value = v)
	layer.add_child(joy)
	var actions := VBoxContainer.new()
	actions.anchor_left = 1
	actions.anchor_top = 1
	actions.anchor_right = 1
	actions.anchor_bottom = 1
	actions.offset_left = -172
	actions.offset_top = -238
	actions.offset_right = -24
	actions.offset_bottom = -24
	actions.add_theme_constant_override("separation", 10)
	layer.add_child(actions)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_END
	actions.add_child(row)
	_add_action_button(row, "ACTION A", "a")
	_add_action_button(row, "ACTION B", "b")
	var block_btn := Button.new()
	block_btn.text = "BLOCK"
	block_btn.custom_minimum_size = Vector2(145, 58)
	block_btn.size_flags_horizontal = Control.SIZE_SHRINK_END
	block_btn.button_down.connect(func(): block_held = true; player.set_blocking(true))
	block_btn.button_up.connect(func(): block_held = false; player.set_blocking(false))
	actions.add_child(block_btn)

func _add_action_button(parent: HBoxContainer, caption: String, action_id: String) -> void:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(70, 70)
	button.pressed.connect(func(): _do_action(action_id))
	parent.add_child(button)

func _do_action(action_id: String) -> void:
	if action_id == "a":
		player.play_sport_action(0)
	else:
		player.play_sport_action(1)

func _physics_process(delta: float) -> void:
	if player == null or rival == null:
		return
	var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var move := joystick_value
	if keyboard.length() > 0.12:
		move = keyboard
	var direction := Vector3(move.x, 0, move.y)
	if direction.length() > 1.0:
		direction = direction.normalized()
	player.velocity.x = direction.x * player.move_speed
	player.velocity.z = direction.z * player.move_speed
	player.velocity.y -= 18.0 * delta
	player.move_and_slide()
	player.position.x = clampf(player.position.x, -4.2, 4.2)
	player.position.z = clampf(player.position.z, -4.2, 4.2)
	var target_player := Vector3(rival.global_position.x, player.global_position.y, rival.global_position.z)
	var target_rival := Vector3(player.global_position.x, rival.global_position.y, player.global_position.z)
	player.look_at(target_player, Vector3.UP)
	rival.look_at(target_rival, Vector3.UP)
	if Input.is_action_just_pressed("strike_a"):
		_do_action("a")
	if Input.is_action_just_pressed("strike_b"):
		_do_action("b")
	var keyboard_block := Input.is_action_pressed("block")
	if keyboard_block != block_held:
		block_held = keyboard_block
		player.set_blocking(block_held)
	# Camera gently frames both competitors and keeps the octagon visible.
	var midpoint := (player.global_position + rival.global_position) * 0.5
	var desired := midpoint + Vector3(0, 7.0, 10.0)
	camera.position = camera.position.lerp(desired, minf(delta * 2.0, 1.0))
	camera.look_at(midpoint + Vector3(0, 0.8, 0), Vector3.UP)
	round_time = maxf(0.0, round_time - delta)
	if status_label:
		var seconds := int(ceil(round_time))
		status_label.text = "ROUND 1  •  %d:%02d" % [seconds / 60, seconds % 60]
