extends CharacterBody3D
class_name DemoFighter

@export var body_color: Color = Color("#2878c8")
@export var glove_color: Color = Color("#e9edf2")
@export var move_speed: float = 3.0
var is_player := false
var is_blocking := false
var visual_root: Node3D
var left_arm: Node3D
var right_arm: Node3D
var action_lock := false

func _ready() -> void:
	_create_visuals()
	floor_snap_length = 0.25

func _make_material(color: Color, roughness := 0.72) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	return mat

func _add_capsule(parent: Node3D, name: String, radius: float, height: float, color: Color, at: Vector3) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = height
	var instance := MeshInstance3D.new()
	instance.name = name
	instance.mesh = mesh
	instance.material_override = _make_material(color)
	instance.position = at
	parent.add_child(instance)
	return instance

func _add_sphere(parent: Node3D, name: String, radius: float, color: Color, at: Vector3) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = name
	instance.mesh = mesh
	instance.material_override = _make_material(color)
	instance.position = at
	parent.add_child(instance)
	return instance

func _create_visuals() -> void:
	visual_root = Node3D.new()
	visual_root.name = "Visuals"
	add_child(visual_root)
	_add_capsule(visual_root, "Torso", 0.34, 1.0, body_color, Vector3(0, 1.15, 0))
	_add_sphere(visual_root, "Head", 0.23, Color("#c99a78"), Vector3(0, 1.88, 0))
	_add_capsule(visual_root, "LeftLeg", 0.14, 0.78, Color("#252b35"), Vector3(-0.16, 0.42, 0))
	_add_capsule(visual_root, "RightLeg", 0.14, 0.78, Color("#252b35"), Vector3(0.16, 0.42, 0))
	left_arm = Node3D.new()
	left_arm.position = Vector3(-0.38, 1.48, 0)
	visual_root.add_child(left_arm)
	_add_capsule(left_arm, "Arm", 0.105, 0.58, Color("#c99a78"), Vector3(0, -0.24, 0))
	_add_sphere(left_arm, "Glove", 0.14, glove_color, Vector3(0, -0.52, -0.03))
	right_arm = Node3D.new()
	right_arm.position = Vector3(0.38, 1.48, 0)
	visual_root.add_child(right_arm)
	_add_capsule(right_arm, "Arm", 0.105, 0.58, Color("#c99a78"), Vector3(0, -0.24, 0))
	_add_sphere(right_arm, "Glove", 0.14, glove_color, Vector3(0, -0.52, -0.03))

func set_blocking(value: bool) -> void:
	is_blocking = value
	var target := -0.55 if value else 0.0
	var tween := create_tween().set_parallel(true)
	tween.tween_property(left_arm, "rotation:x", target, 0.12)
	tween.tween_property(right_arm, "rotation:x", target, 0.12)

func play_sport_action(side: int) -> void:
	if action_lock or is_blocking:
		return
	action_lock = true
	var arm := left_arm if side == 0 else right_arm
	var original := arm.rotation
	var tween := create_tween()
	tween.tween_property(arm, "rotation", original + Vector3(-0.9, 0, -0.35 if side == 0 else 0.35), 0.10)
	tween.tween_property(arm, "rotation", original, 0.16)
	tween.finished.connect(func(): action_lock = false)
