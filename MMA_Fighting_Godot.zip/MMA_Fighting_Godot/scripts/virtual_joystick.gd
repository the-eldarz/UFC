extends Control
signal vector_changed(value: Vector2)

var pointer_id := -1
var knob := Vector2.ZERO
var radius := 62.0

func _ready() -> void:
	custom_minimum_size = Vector2(170, 170)
	mouse_filter = Control.MOUSE_FILTER_STOP

func _draw() -> void:
	var center := size * 0.5
	draw_circle(center, radius, Color(0.05, 0.08, 0.12, 0.48))
	draw_arc(center, radius, 0, TAU, 64, Color(0.8, 0.88, 1.0, 0.6), 3.0)
	draw_circle(center + knob, 29.0, Color(0.75, 0.83, 0.95, 0.82))
	draw_arc(center + knob, 29.0, 0, TAU, 48, Color(1, 1, 1, 0.8), 2.0)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and pointer_id == -1:
			pointer_id = event.index
			_update_knob(event.position)
		elif not event.pressed and event.index == pointer_id:
			pointer_id = -1
			knob = Vector2.ZERO
			vector_changed.emit(Vector2.ZERO)
			queue_redraw()
	elif event is InputEventScreenDrag and event.index == pointer_id:
		_update_knob(event.position)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			pointer_id = 0
			_update_knob(event.position)
		else:
			pointer_id = -1
			knob = Vector2.ZERO
			vector_changed.emit(Vector2.ZERO)
			queue_redraw()
	elif event is InputEventMouseMotion and pointer_id == 0 and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		_update_knob(event.position)

func _update_knob(local_pos: Vector2) -> void:
	var delta := local_pos - size * 0.5
	knob = delta.limit_length(radius)
	vector_changed.emit(Vector2(knob.x / radius, -knob.y / radius))
	queue_redraw()
